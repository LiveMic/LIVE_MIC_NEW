using System;
using System.Drawing;
using System.Windows.Forms;

namespace LIVE_MIC;

internal sealed class SettingsForm : Form
{
    private readonly TrackBar _sizeSlider;
    private readonly TrackBar _transparencySlider;
    private readonly Label _sizeValueLabel;
    private readonly Label _transparencyValueLabel;

    public event EventHandler<(int Size, int Transparency)>? SettingsChanged;
    public event EventHandler? DefaultsRequested;

    public SettingsForm(AppSettings settings)
    {
        Text = "LIVE_MIC Settings";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(360, 220);

        Label sizeLabel = new()
        {
            Text = "Size",
            AutoSize = true,
            Location = new Point(18, 18)
        };

        _sizeSlider = new TrackBar
        {
            Minimum = 20,
            Maximum = 300,
            TickFrequency = 20,
            SmallChange = 5,
            LargeChange = 20,
            Width = 250,
            Location = new Point(18, 38),
            Value = Math.Clamp(settings.SizePixels, 20, 300)
        };
        _sizeSlider.ValueChanged += (_, _) => RaiseSettingsChanged();

        _sizeValueLabel = new Label
        {
            AutoSize = true,
            Location = new Point(280, 42)
        };

        Label transparencyLabel = new()
        {
            Text = "Transparency",
            AutoSize = true,
            Location = new Point(18, 98)
        };

        _transparencySlider = new TrackBar
        {
            Minimum = 0,
            Maximum = 100,
            TickFrequency = 10,
            SmallChange = 1,
            LargeChange = 10,
            Width = 250,
            Location = new Point(18, 118),
            Value = Math.Clamp(settings.TransparencyPercent, 0, 100)
        };
        _transparencySlider.ValueChanged += (_, _) => RaiseSettingsChanged();

        _transparencyValueLabel = new Label
        {
            AutoSize = true,
            Location = new Point(280, 122)
        };

        Button resetButton = new()
        {
            Text = "Reset to default",
            Width = 120,
            Height = 30,
            Location = new Point(18, 175)
        };
        resetButton.Click += (_, _) => DefaultsRequested?.Invoke(this, EventArgs.Empty);

        Button closeButton = new()
        {
            Text = "Close",
            Width = 90,
            Height = 30,
            Location = new Point(252, 175)
        };
        closeButton.Click += (_, _) => Close();

        Controls.AddRange(
        [
            sizeLabel,
            _sizeSlider,
            _sizeValueLabel,
            transparencyLabel,
            _transparencySlider,
            _transparencyValueLabel,
            resetButton,
            closeButton
        ]);

        UpdateValueLabels();
    }

    public void ApplySettings(AppSettings settings)
    {
        _sizeSlider.Value = Math.Clamp(settings.SizePixels, _sizeSlider.Minimum, _sizeSlider.Maximum);
        _transparencySlider.Value = Math.Clamp(settings.TransparencyPercent, _transparencySlider.Minimum, _transparencySlider.Maximum);
        UpdateValueLabels();
    }

    private void RaiseSettingsChanged()
    {
        UpdateValueLabels();
        SettingsChanged?.Invoke(this, (_sizeSlider.Value, _transparencySlider.Value));
    }

    private void UpdateValueLabels()
    {
        _sizeValueLabel.Text = $"{_sizeSlider.Value}px";
        _transparencyValueLabel.Text = $"{_transparencySlider.Value}%";
    }
}
