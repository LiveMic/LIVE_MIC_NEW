namespace LIVE_MIC;

internal sealed class AppSettings
{
    public const int DefaultSize = 80;
    public const int DefaultTransparencyPercent = 20;

    public bool IndicatorEnabled { get; set; } = true;
    public int SizePixels { get; set; } = DefaultSize;
    public int TransparencyPercent { get; set; } = DefaultTransparencyPercent; // 0 = solid, 100 = invisible

    public void ResetToDefaults()
    {
        IndicatorEnabled = true;
        SizePixels = DefaultSize;
        TransparencyPercent = DefaultTransparencyPercent;
    }
}
