using System;
using System.Drawing;
using System.Windows.Forms;

namespace LIVE_MIC;

internal sealed class LiveMicApplicationContext : ApplicationContext
{
    private readonly AppSettings _settings = new();
    private readonly OverlayForm _overlay;
    private readonly AudioMuteWatcher _muteWatcher;
    private readonly NotifyIcon _notifyIcon;
    private readonly ToolStripMenuItem _enabledMenuItem;
    private SettingsForm? _settingsForm;

    public LiveMicApplicationContext()
    {
        _overlay = new OverlayForm(_settings.SizePixels, _settings.TransparencyPercent);
        _muteWatcher = new AudioMuteWatcher();
        _muteWatcher.MuteChanged += OnMuteChanged;

        _enabledMenuItem = new ToolStripMenuItem("Active") { CheckOnClick = true, Checked = _settings.IndicatorEnabled };
        _enabledMenuItem.CheckedChanged += (_, _) =>
        {
            _settings.IndicatorEnabled = _enabledMenuItem.Checked;
            UpdateOverlayVisibility();
        };

        ToolStripMenuItem settingsMenuItem = new("Settings...");
        settingsMenuItem.Click += (_, _) => ShowSettingsForm();

        ToolStripMenuItem refreshMenuItem = new("Refresh audio device");
        refreshMenuItem.Click += (_, _) => RefreshAudioDevice();

        ToolStripMenuItem exitMenuItem = new("Exit");
        exitMenuItem.Click += (_, _) => ExitThread();

        ContextMenuStrip trayMenu = new();
        trayMenu.Items.Add(new ToolStripMenuItem("LIVE_MIC") { Enabled = false });
        trayMenu.Items.Add(new ToolStripSeparator());
        trayMenu.Items.Add(_enabledMenuItem);
        trayMenu.Items.Add(settingsMenuItem);
        trayMenu.Items.Add(refreshMenuItem);
        trayMenu.Items.Add(new ToolStripSeparator());
        trayMenu.Items.Add(exitMenuItem);

        _notifyIcon = new NotifyIcon
        {
            Text = "LIVE_MIC",
            Icon = SystemIcons.Information,
            Visible = true,
            ContextMenuStrip = trayMenu
        };
        _notifyIcon.DoubleClick += (_, _) => ShowSettingsForm();

        RefreshAudioDevice();
    }

    protected override void ExitThreadCore()
    {
        _notifyIcon.Visible = false;
        _notifyIcon.Dispose();
        _settingsForm?.Close();
        _settingsForm?.Dispose();
        _muteWatcher.Dispose();
        _overlay.Close();
        _overlay.Dispose();
        base.ExitThreadCore();
    }

    private void ShowSettingsForm()
    {
        if (_settingsForm is null || _settingsForm.IsDisposed)
        {
            _settingsForm = new SettingsForm(_settings);
            _settingsForm.SettingsChanged += (_, values) =>
            {
                _settings.SizePixels = values.Size;
                _settings.TransparencyPercent = values.Transparency;
                _overlay.ApplySettings(_settings.SizePixels, _settings.TransparencyPercent);
                UpdateOverlayVisibility();
            };
            _settingsForm.DefaultsRequested += (_, _) =>
            {
                _settings.ResetToDefaults();
                _enabledMenuItem.Checked = _settings.IndicatorEnabled;
                _settingsForm?.ApplySettings(_settings);
                _overlay.ApplySettings(_settings.SizePixels, _settings.TransparencyPercent);
                UpdateOverlayVisibility();
            };
            _settingsForm.FormClosed += (_, _) => _settingsForm = null;
        }

        _settingsForm.ApplySettings(_settings);
        _settingsForm.Show();
        _settingsForm.BringToFront();
        _settingsForm.Activate();
    }

    private void RefreshAudioDevice()
    {
        bool ok = _muteWatcher.TryInitialize();
        if (!ok)
        {
            _notifyIcon.ShowBalloonTip(3000, "LIVE_MIC", "Could not find the default microphone device.", ToolTipIcon.Warning);
        }

        UpdateOverlayVisibility();
        _muteWatcher.RaiseMuteChanged();
    }

    private void OnMuteChanged(object? sender, bool isMuted)
    {
        if (_overlay.InvokeRequired)
        {
            _overlay.BeginInvoke(new Action(() => OnMuteChanged(sender, isMuted)));
            return;
        }

        _overlay.SetMuted(isMuted);
        UpdateOverlayVisibility();
    }

    private void UpdateOverlayVisibility()
    {
        bool invisibleByTransparency = _settings.TransparencyPercent >= 100;
        bool shouldShow = _settings.IndicatorEnabled && !invisibleByTransparency;

        if (shouldShow)
        {
            if (!_overlay.Visible)
            {
                _overlay.Show();
            }

            _overlay.ApplySettings(_settings.SizePixels, _settings.TransparencyPercent);
        }
        else
        {
            _overlay.Hide();
        }
    }
}
