using System;
using System.Runtime.InteropServices;

namespace LIVE_MIC;

internal sealed class AudioMuteWatcher : IAudioEndpointVolumeCallback, IDisposable
{
    private IMMDeviceEnumerator? _deviceEnumerator;
    private IMMDevice? _device;
    private IAudioEndpointVolume? _endpointVolume;

    public event EventHandler<bool>? MuteChanged;

    public bool TryInitialize()
    {
        CleanupAudioObjects();

        try
        {
            _deviceEnumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorComObject();

            if (!TryBindRole(ERole.eCommunications) && !TryBindRole(ERole.eMultimedia) && !TryBindRole(ERole.eConsole))
            {
                return false;
            }

            _endpointVolume!.RegisterControlChangeNotify(this);
            return true;
        }
        catch
        {
            CleanupAudioObjects();
            return false;
        }
    }

    public void RaiseMuteChanged()
    {
        if (_endpointVolume is null)
        {
            return;
        }

        _endpointVolume.GetMute(out bool isMuted);
        MuteChanged?.Invoke(this, isMuted);
    }

    private bool TryBindRole(ERole role)
    {
        if (_deviceEnumerator is null)
        {
            return false;
        }

        int hr = _deviceEnumerator.GetDefaultAudioEndpoint(EDataFlow.eCapture, role, out IMMDevice device);
        if (hr != 0 || device is null)
        {
            return false;
        }

        Guid iid = typeof(IAudioEndpointVolume).GUID;
        hr = device.Activate(ref iid, 23, IntPtr.Zero, out object endpointObject);
        if (hr != 0 || endpointObject is not IAudioEndpointVolume endpointVolume)
        {
            Marshal.ReleaseComObject(device);
            return false;
        }

        _device = device;
        _endpointVolume = endpointVolume;
        return true;
    }

    public int OnNotify(IntPtr pNotify)
    {
        RaiseMuteChanged();
        return 0;
    }

    public void Dispose()
    {
        CleanupAudioObjects();
        GC.SuppressFinalize(this);
    }

    private void CleanupAudioObjects()
    {
        if (_endpointVolume is not null)
        {
            try
            {
                _endpointVolume.UnregisterControlChangeNotify(this);
            }
            catch
            {
            }

            Marshal.ReleaseComObject(_endpointVolume);
            _endpointVolume = null;
        }

        if (_device is not null)
        {
            Marshal.ReleaseComObject(_device);
            _device = null;
        }

        if (_deviceEnumerator is not null)
        {
            Marshal.ReleaseComObject(_deviceEnumerator);
            _deviceEnumerator = null;
        }
    }
}
